.. -*- mode: rst -*-

This folder will contain SVG sample files for the `svglib`
testsuite. These files will be downloaded from the internet
during the test runs if they are not already present.
