from .xml import Langvalue

__all__ = [
    "Langvalue",
]
