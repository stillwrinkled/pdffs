from typing import List

from pyhanko.cli import launch

__all__: List[str] = []


if __name__ == '__main__':
    launch()
